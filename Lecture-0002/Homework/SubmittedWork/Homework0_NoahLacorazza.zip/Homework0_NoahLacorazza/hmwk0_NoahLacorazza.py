# File: hmwk0_NoahLacorazza.py
# Author: Noah Lacorazza
# Date: 9/12/5
# Section: 1004
# E-mail: noah.lacorazza@maine.edu
# Description:
# Prints my name, 3 text-based games, an empty line, then my favorite color.
# Collaboration:
# N/A

print("Noah Lacorazza")
print("Bitburner")
print("heads or tails")
print("Emily is Away")
print("")
print("Blue")