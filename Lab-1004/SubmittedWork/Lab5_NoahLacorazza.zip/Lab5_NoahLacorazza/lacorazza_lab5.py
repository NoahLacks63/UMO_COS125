condition = False

while condition:
    #code to run if the logical check is True
    #update condition

for item in range(3):
    #code to execute until list is completed
    
for iteration in range(3):
    #code to execute until known repeats are completed