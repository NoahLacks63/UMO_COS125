print("hello world")
print("Noah")